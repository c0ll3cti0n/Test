<?
$user_agent = "Mozilla/5.0 (Linux; Android 7.11.2; Redmi 4A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36";
$email = "tajibaevaan@gmail.com";
$pass = "534029an";
$pass_scrip = "member";


